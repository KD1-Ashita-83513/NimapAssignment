﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WebApplication1.Models;

namespace Nimap.Entities
{
    [Table("Products")]
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [MaxLength(100)] // Set the max length as per your requirements
        public string Name { get; set; }

        [Required]
        [Range(0, double.MaxValue)] // Ensure price is a positive value
        public double Price { get; set; }

        [ForeignKey("CategoryId")]
        public long CategoryId { get; set; } // Foreign key property

        public virtual Category Category { get; set; } // Navigation property
    }
}
