﻿using Microsoft.AspNetCore.Mvc;
using Nimap.DTOs;
using Nimap.Services;

namespace Nimap.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        // Get all products with pagination
        [HttpGet]
        public IActionResult GetAllProducts([FromQuery] int page = 0, [FromQuery] int size = 10)
        {
            try
            {
                var products = _productService.GetAllProducts(page, size);
                return Ok(products);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Get product by ID
        [HttpGet("{id}")]
        public IActionResult GetProductById(long id)
        {
            try
            {
                var product = _productService.GetById(id);
                if (product == null)
                    return NotFound($"Product with ID {id} not found.");

                return Ok(product);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Create a new product
        [HttpPost]
        public IActionResult CreateProduct([FromBody] ProductRequestDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var createdProduct = _productService.CreateProduct(dto);
                return Ok(createdProduct);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Update an existing product
        [HttpPut("{id}")]
        public IActionResult UpdateProduct(long id, [FromBody] ProductRequestDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var updatedProduct = _productService.UpdateProduct(id, dto);
                if (updatedProduct == null)
                    return NotFound($"Product with ID {id} not found.");

                return Ok(updatedProduct);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Delete product by ID
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(long id)
        {
            try
            {
                var isDeleted = _productService.DeleteProductById(id);
                if (!isDeleted)
                    return NotFound($"Product with ID {id} not found.");

                return Ok($"Product with ID {id} deleted successfully.");
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }
    }
}
