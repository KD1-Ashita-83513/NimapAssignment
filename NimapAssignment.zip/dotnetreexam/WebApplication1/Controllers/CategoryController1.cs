﻿using Microsoft.AspNetCore.Mvc;
using Nimap.DTOs;
using Nimap.Services;

namespace Nimap.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        // Get all categories with pagination
        [HttpGet]
        public IActionResult GetAllCategories([FromQuery] int page = 0, [FromQuery] int size = 10)
        {
            try
            {
                var categories = _categoryService.GetAllCategories(page, size);
                return Ok(categories);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Create a new category
        [HttpPost]
        public IActionResult CreateCategory([FromBody] CategoryRequestDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var createdCategory = _categoryService.AddCategory(dto);
                return Ok(createdCategory);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Get category by ID
        [HttpGet("{id}")]
        public IActionResult GetCategoryById(long id)
        {
            try
            {
                var category = _categoryService.GetById(id);
                if (category == null)
                    return NotFound($"Category with ID {id} not found.");

                return Ok(category);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Update category by ID
        [HttpPut("{id}")]
        public IActionResult UpdateCategoryById(long id, [FromBody] CategoryRequestDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var updatedCategory = _categoryService.UpdateCategory(id, dto);
                if (updatedCategory == null)
                    return NotFound($"Category with ID {id} not found.");

                return Ok(updatedCategory);
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }

        // Delete category by ID
        [HttpDelete("{id}")]
        public IActionResult DeleteCategoryById(long id)
        {
            try
            {
                var isDeleted = _categoryService.DeleteCategory(id);
                if (!isDeleted)
                    return NotFound($"Category with ID {id} not found.");

                return Ok($"Category with ID {id} deleted successfully.");
            }
            catch (Exception)
            {
                return BadRequest("Something went wrong!!");
            }
        }
    }
}
